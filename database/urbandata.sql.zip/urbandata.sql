-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 01, 2018 at 11:40 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `urbandata`
--

-- --------------------------------------------------------

--
-- Table structure for table `site_constant`
--

DROP TABLE IF EXISTS `site_constant`;
CREATE TABLE `site_constant` (
  `id` int(11) NOT NULL,
  `site_name` varchar(500) NOT NULL,
  `site_short_name` varchar(500) NOT NULL,
  `admin_name` varchar(300) NOT NULL,
  `admin_email` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `site_constant`
--

INSERT INTO `site_constant` (`id`, `site_name`, `site_short_name`, `admin_name`, `admin_email`) VALUES
(1, 'UrbanData', 'UrbanData', 'No Reply', 'ajay546k@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `udm_decisionspace`
--

DROP TABLE IF EXISTS `udm_decisionspace`;
CREATE TABLE `udm_decisionspace` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` enum('Private','Public') NOT NULL DEFAULT 'Public',
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `path` text NOT NULL,
  `num_views` int(11) NOT NULL DEFAULT '0',
  `chk_rating_added` int(11) NOT NULL,
  `chk_likedislikes_added` int(11) NOT NULL,
  `average_rating` decimal(2,2) NOT NULL,
  `num_likes` int(11) NOT NULL,
  `num_dislikes` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `udm_decisionspace`
--

INSERT INTO `udm_decisionspace` (`id`, `user_id`, `type`, `title`, `description`, `path`, `num_views`, `chk_rating_added`, `chk_likedislikes_added`, `average_rating`, `num_likes`, `num_dislikes`, `published`, `deleted`, `created_date`, `updated`) VALUES
(1, 6, 'Public', 'London underground renewal discussion', 'demonstrator', '', 25, 0, 1, '0.00', 0, 0, 1, 0, '2017-05-08 10:23:28', '2017-05-08 10:23:28'),
(2, 10, 'Private', 'UrbanData2Decide Decision Space', '', '', 28, 0, 0, '0.00', 0, 0, 1, 0, '2017-06-16 13:04:25', '2017-06-16 14:40:57'),
(3, 2, 'Public', 'test', 'esrt', 'ds/2/1519463853Vacancies.jpg', 22, 0, 0, '0.00', 0, 0, 0, 0, '2018-02-24 09:17:33', '2018-02-24 09:17:33');

-- --------------------------------------------------------

--
-- Table structure for table `udm_decisionspace_comments`
--

DROP TABLE IF EXISTS `udm_decisionspace_comments`;
CREATE TABLE `udm_decisionspace_comments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `decisionspace_id` int(11) NOT NULL,
  `ds_vis_id` int(11) NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  `dt_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `udm_decisionspace_comments`
--

INSERT INTO `udm_decisionspace_comments` (`id`, `user_id`, `decisionspace_id`, `ds_vis_id`, `message`, `dt_added`) VALUES
(1, 6, 1, 1, 'Looks fine and nice and empty today', '2017-05-08 10:26:15'),
(3, 2, 3, 6, 'testing messages.', '2018-02-24 18:38:46');

-- --------------------------------------------------------

--
-- Table structure for table `udm_decisionspace_invitations`
--

DROP TABLE IF EXISTS `udm_decisionspace_invitations`;
CREATE TABLE `udm_decisionspace_invitations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `decisionspace_id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `role` enum('Member','Viewer') NOT NULL DEFAULT 'Viewer',
  `registered` char(1) NOT NULL DEFAULT '0',
  `dt_send` datetime NOT NULL,
  `dt_registered` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `udm_decisionspace_invitations`
--

INSERT INTO `udm_decisionspace_invitations` (`id`, `user_id`, `decisionspace_id`, `name`, `email`, `role`, `registered`, `dt_send`, `dt_registered`) VALUES
(1, 6, 1, 'Thomas Paulin', 'thomas.paulin@synyo.com', '', '0', '2017-05-08 10:23:28', NULL),
(2, 10, 2, 'Urban Data', 'office@urbandata2decide.eu', 'Viewer', '0', '2017-06-16 14:41:44', NULL),
(3, 2, 3, 'tet', 'test@ddd.ujj', 'Viewer', '0', '2018-02-24 09:17:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `udm_decisionspace_vis`
--

DROP TABLE IF EXISTS `udm_decisionspace_vis`;
CREATE TABLE `udm_decisionspace_vis` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `decisionspace_id` int(11) NOT NULL,
  `vis_id` int(11) NOT NULL,
  `chk_comments_added` char(1) NOT NULL DEFAULT '0',
  `chk_rating_added` char(1) NOT NULL DEFAULT '0',
  `chk_likedislikes_added` char(1) NOT NULL DEFAULT '0',
  `average_rating` float NOT NULL,
  `num_likes` int(11) NOT NULL,
  `num_dislikes` int(11) NOT NULL,
  `dt_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `udm_decisionspace_vis`
--

INSERT INTO `udm_decisionspace_vis` (`id`, `user_id`, `decisionspace_id`, `vis_id`, `chk_comments_added`, `chk_rating_added`, `chk_likedislikes_added`, `average_rating`, `num_likes`, `num_dislikes`, `dt_added`) VALUES
(1, 6, 1, 1, '1', '1', '0', 5, 0, 0, '2017-05-08 10:24:59'),
(8, 10, 2, 5, '0', '0', '0', 0, 0, 0, '2017-06-27 09:26:49'),
(10, 11, 2, 3, '0', '0', '0', 0, 0, 0, '2017-06-30 13:34:42'),
(11, 2, 3, 6, '1', '1', '1', 5, 1, 1, '2018-02-24 17:57:38');

-- --------------------------------------------------------

--
-- Table structure for table `udm_featurectrl`
--

DROP TABLE IF EXISTS `udm_featurectrl`;
CREATE TABLE `udm_featurectrl` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `decisionspace_id` int(11) NOT NULL,
  `title` varchar(300) NOT NULL,
  `description` text NOT NULL,
  `type` enum('Rating','LikeDislikes') NOT NULL,
  `dt_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `udm_likes_dislikes`
--

DROP TABLE IF EXISTS `udm_likes_dislikes`;
CREATE TABLE `udm_likes_dislikes` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `decisionspace_id` int(11) NOT NULL,
  `vis_id` int(11) NOT NULL DEFAULT '0',
  `type` enum('Like','Dislike') NOT NULL DEFAULT 'Like',
  `dt_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `udm_likes_dislikes`
--

INSERT INTO `udm_likes_dislikes` (`id`, `user_id`, `decisionspace_id`, `vis_id`, `type`, `dt_added`) VALUES
(1, 10, 2, 2, 'Like', '2017-06-28 07:15:43'),
(6, 2, 3, 6, 'Dislike', '2018-02-24 18:01:51'),
(5, 2, 3, 6, 'Like', '2018-02-24 18:01:47');

-- --------------------------------------------------------

--
-- Table structure for table `udm_notifications`
--

DROP TABLE IF EXISTS `udm_notifications`;
CREATE TABLE `udm_notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `decisionspace_id` int(11) NOT NULL,
  `vis_id` int(11) NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  `chk_read` char(1) NOT NULL DEFAULT '0',
  `dt_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `udm_notifications`
--

INSERT INTO `udm_notifications` (`id`, `user_id`, `decisionspace_id`, `vis_id`, `message`, `chk_read`, `dt_added`) VALUES
(1, 1, 1, 1, 'A visualisation added to decision space - London underground renewal discussion', '0', '2017-05-08 10:24:59'),
(2, 1, 1, 1, 'A comment posted by Yvonne Dittrich on decision space - London underground renewal discussion', '0', '2017-05-08 10:26:15'),
(3, 1, 1, 0, 'You have been invited to decision space - London underground renewal discussion', '0', '2017-05-22 08:34:56'),
(4, 1, 2, 2, 'A visualisation added to decision space - Social Data 4 All', '0', '2017-06-16 13:52:37'),
(5, 1, 2, 3, 'A visualisation added to decision space - Social Data 4 All', '0', '2017-06-16 13:52:49'),
(6, 1, 2, 5, 'A visualisation added to decision space - Social Data 4 All', '0', '2017-06-16 14:03:55'),
(7, 1, 2, 4, 'A visualisation added to decision space - Social Data 4 All', '0', '2017-06-16 14:04:15'),
(8, 10, 11, 0, 'You have been invited to decision space - UrbanData2Decide Decision Space', '1', '2017-06-16 14:41:44'),
(9, 1, 2, 2, 'A visualisation added to decision space - UrbanData2Decide Decision Space', '0', '2017-06-27 09:22:31'),
(10, 11, 2, 2, 'A visualisation added to decision space - UrbanData2Decide Decision Space', '1', '2017-06-27 09:22:31'),
(11, 1, 2, 4, 'A visualisation added to decision space - UrbanData2Decide Decision Space', '0', '2017-06-27 09:24:44'),
(12, 11, 2, 4, 'A visualisation added to decision space - UrbanData2Decide Decision Space', '1', '2017-06-27 09:24:44'),
(13, 1, 2, 5, 'A visualisation added to decision space - UrbanData2Decide Decision Space', '0', '2017-06-27 09:26:49'),
(14, 11, 2, 5, 'A visualisation added to decision space - UrbanData2Decide Decision Space', '1', '2017-06-27 09:26:49'),
(15, 1, 2, 2, 'A visualisation added to decision space - UrbanData2Decide Decision Space', '0', '2017-06-27 16:27:47'),
(16, 11, 2, 2, 'A visualisation added to decision space - UrbanData2Decide Decision Space', '1', '2017-06-27 16:27:47'),
(17, 1, 2, 4, 'A comment posted by Thomas Paulin on decision space - UrbanData2Decide Decision Space', '0', '2017-06-28 07:16:36'),
(18, 11, 2, 4, 'A comment posted by Thomas Paulin on decision space - UrbanData2Decide Decision Space', '1', '2017-06-28 07:16:36'),
(19, 1, 2, 3, 'A visualisation added to decision space - UrbanData2Decide Decision Space', '0', '2017-06-30 13:34:42'),
(20, 11, 2, 3, 'A visualisation added to decision space - UrbanData2Decide Decision Space', '0', '2017-06-30 13:34:42'),
(21, 1, 3, 6, 'A visualisation added to decision space - test', '0', '2018-02-24 17:57:38'),
(22, 1, 3, 6, 'A comment posted by Ajay Kumar on decision space - test', '0', '2018-02-24 18:38:46');

-- --------------------------------------------------------

--
-- Table structure for table `udm_ratings`
--

DROP TABLE IF EXISTS `udm_ratings`;
CREATE TABLE `udm_ratings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `decisionspace_id` int(11) NOT NULL,
  `vis_id` int(11) NOT NULL DEFAULT '0',
  `rating` float NOT NULL,
  `dt_rated` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `udm_ratings`
--

INSERT INTO `udm_ratings` (`id`, `user_id`, `decisionspace_id`, `vis_id`, `rating`, `dt_rated`) VALUES
(1, 6, 1, 1, 5, '2017-05-08 10:26:01'),
(2, 10, 2, 2, 4.5, '2017-06-28 07:15:53'),
(3, 2, 3, 6, 5, '2018-02-24 18:02:11');

-- --------------------------------------------------------

--
-- Table structure for table `udm_user`
--

DROP TABLE IF EXISTS `udm_user`;
CREATE TABLE `udm_user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `title` varchar(20) NOT NULL,
  `first_name` varchar(300) NOT NULL,
  `middle_name` varchar(300) NOT NULL,
  `last_name` varchar(300) NOT NULL,
  `organisation` varchar(300) NOT NULL,
  `street` text,
  `city` varchar(300) DEFAULT NULL,
  `state` varchar(300) DEFAULT NULL,
  `country` varchar(300) DEFAULT NULL,
  `postcode` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `photo` text,
  `gender` enum('Male','Female') NOT NULL DEFAULT 'Male',
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `roles` enum('Admin','User') NOT NULL DEFAULT 'User',
  `status` enum('A','D') NOT NULL DEFAULT 'D',
  `approved` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `udm_user`
--

INSERT INTO `udm_user` (`id`, `username`, `title`, `first_name`, `middle_name`, `last_name`, `organisation`, `street`, `city`, `state`, `country`, `postcode`, `phone`, `photo`, `gender`, `email`, `password`, `roles`, `status`, `approved`, `deleted`, `last_login`, `updated_on`, `created_date`) VALUES
(2, 'ajay', 'Mr.', 'Ajay', '', 'Kumar', 'Tech Spruce', '', '', '', '', '', '', NULL, 'Male', 'ajay546k@gmail.com', '06180b3774e149e71af19183da2c148c05d48a38', 'User', 'A', 'Y', 0, '2018-02-25 03:25:11', '2017-04-07 14:43:10', '2017-03-22 16:18:02'),
(1, 'admin', 'Mr.', 'Admin', '', '', '', '', '', '', '', '', '', NULL, 'Male', 'admin@urbandata.com', '06180b3774e149e71af19183da2c148c05d48a38', 'Admin', 'A', 'Y', 0, '2018-02-27 10:51:38', NULL, '2017-03-27 00:00:00'),
(6, 'yvonne', 'Dr.', 'Yvonne', '', 'Dittrich', 'IT University of Copenhagen', '', '', '', '', '', '', NULL, 'Female', 'ydi@itu.dk', '0a442e3ee05fa4425a8a87d16b011c16bcd3fc6f', 'User', 'A', 'Y', 0, '2017-05-08 10:26:54', NULL, '2017-04-03 19:34:06'),
(11, 'UD2D', 'Miss.', 'Urban', 'Data', 'Decide', 'UrbanData2Decide', '', '', '', '', '', '', NULL, 'Male', 'office@urbandata2decide.eu', '4f55d50c032815db8860f3087f5318d2644daf3a', 'User', 'A', 'Y', 0, '2017-07-04 15:02:44', '2017-06-28 14:32:37', '2017-06-16 14:27:12'),
(10, 'tpaulin', 'Mr.', 'Thomas', '', 'Paulin', 'SYNYO', '', '', '', '', '', '', NULL, 'Male', 'thomas.paulin@synyo.com', '054701228cd5009eb9599569645a753dac4f59f0', 'User', 'A', 'Y', 0, '2017-07-20 07:24:40', NULL, '2017-05-22 08:34:56');

-- --------------------------------------------------------

--
-- Table structure for table `udm_visctrl`
--

DROP TABLE IF EXISTS `udm_visctrl`;
CREATE TABLE `udm_visctrl` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `decisionspace_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `url` text NOT NULL,
  `image` text NOT NULL,
  `description` text NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `udm_visctrl`
--

INSERT INTO `udm_visctrl` (`id`, `user_id`, `decisionspace_id`, `title`, `url`, `image`, `description`, `deleted`, `created_date`) VALUES
(1, 6, 1, 'London Victoria line heatmap', 'http://goingunderground.herokuapp.com/heatmap', '', 'This is to show ocupation on the victoria line', 0, '2017-05-08 10:24:42'),
(2, 10, 2, 'Research Map', 'http://ud2d:urbandata2decide2017@soldemo.urbandata2decide.eu/en/researchmap', '', 'Distribution of H2020 Research Funding per District in Austria', 0, '2017-06-16 13:05:43'),
(3, 10, 2, 'Social Media ', 'http://ud2d:urbandata2decide2017@soldemo.urbandata2decide.eu/en/socialcityviewer', '', 'Social Media Data', 0, '2017-06-16 13:06:17'),
(4, 10, 2, 'London Map', 'http://goingunderground.herokuapp.com/heatmap', '', 'Current Underground Load', 0, '2017-06-16 13:07:04'),
(5, 10, 2, 'Open Data Emergency Map', 'http://ud2d:urbandata2decide2017@soldemo.urbandata2decide.eu/en/opendatamap', '', 'Visualisation of Emergency Services', 0, '2017-06-16 13:54:43'),
(6, 2, 3, 'test', 'https://www.facebook.com/', '', 'aeasd asdf adf as df', 0, '2018-02-24 17:57:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `site_constant`
--
ALTER TABLE `site_constant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `udm_decisionspace`
--
ALTER TABLE `udm_decisionspace`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `udm_decisionspace_comments`
--
ALTER TABLE `udm_decisionspace_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `udm_decisionspace_invitations`
--
ALTER TABLE `udm_decisionspace_invitations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `udm_decisionspace_vis`
--
ALTER TABLE `udm_decisionspace_vis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `udm_featurectrl`
--
ALTER TABLE `udm_featurectrl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `udm_likes_dislikes`
--
ALTER TABLE `udm_likes_dislikes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `udm_notifications`
--
ALTER TABLE `udm_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `udm_ratings`
--
ALTER TABLE `udm_ratings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `udm_user`
--
ALTER TABLE `udm_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `udm_visctrl`
--
ALTER TABLE `udm_visctrl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `site_constant`
--
ALTER TABLE `site_constant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `udm_decisionspace`
--
ALTER TABLE `udm_decisionspace`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `udm_decisionspace_comments`
--
ALTER TABLE `udm_decisionspace_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `udm_decisionspace_invitations`
--
ALTER TABLE `udm_decisionspace_invitations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `udm_decisionspace_vis`
--
ALTER TABLE `udm_decisionspace_vis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `udm_featurectrl`
--
ALTER TABLE `udm_featurectrl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `udm_likes_dislikes`
--
ALTER TABLE `udm_likes_dislikes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `udm_notifications`
--
ALTER TABLE `udm_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `udm_ratings`
--
ALTER TABLE `udm_ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `udm_user`
--
ALTER TABLE `udm_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `udm_visctrl`
--
ALTER TABLE `udm_visctrl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
